to use the example in release-x86-windows
unpack this rar file : https://anonfile.com/deU2a7r8oc/libs_rar into this folder

to use the example in release-x64-windows
unpack this rar file : https://anonfile.com/Hbr6P1w5o7/libs_zip into this folder

if you want different compilation settings, compile CryptoPP and cURL[OPENSSL] in the mode you want

this packages were installed with vcpkg


( cauth dependencies )

